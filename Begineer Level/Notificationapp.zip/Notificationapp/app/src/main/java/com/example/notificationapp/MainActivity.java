package com.example.notificationapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity {

    Button notifyBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notifyBtn = findViewById(R.id.notifyBtn);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "channel1",
                    "MyChannel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        notifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NotificationCompat.Builder builder =
                        new NotificationCompat.Builder(MainActivity.this, "channel1")
                                .setSmallIcon(android.R.drawable.ic_dialog_info)
                                .setContentTitle("New Notification")
                                .setContentText("This is a notification example");

                NotificationManagerCompat manager =
                        NotificationManagerCompat.from(MainActivity.this);

                manager.notify(1, builder.build());

                Toast.makeText(MainActivity.this,
                        "Notification Inserted : New Notification - This is a notification example",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}