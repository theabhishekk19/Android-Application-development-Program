package com.example.formapp;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText username,password,address,age;
    RadioGroup genderGroup;
    DatePicker dob;
    Spinner state;
    Button submit;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        address=findViewById(R.id.address);
        age=findViewById(R.id.age);
        genderGroup=findViewById(R.id.genderGroup);
        dob=findViewById(R.id.dob);
        state=findViewById(R.id.state);
        submit=findViewById(R.id.submit);
        result=findViewById(R.id.result);

        String states[]={"Delhi","Haryana","Punjab","UP","Rajasthan"};

        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,states);
        state.setAdapter(adapter);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user=username.getText().toString();
                String pass=password.getText().toString();
                String addr=address.getText().toString();
                String ag=age.getText().toString();

                int selectedId=genderGroup.getCheckedRadioButtonId();
                RadioButton gender=findViewById(selectedId);

                String dobText=dob.getDayOfMonth()+"/"+(dob.getMonth()+1)+"/"+dob.getYear();
                String stateText=state.getSelectedItem().toString();

                result.setText(
                        "Username: "+user+
                                "\nPassword: "+pass+
                                "\nAddress: "+addr+
                                "\nGender: "+gender.getText()+
                                "\nAge: "+ag+
                                "\nDOB: "+dobText+
                                "\nState: "+stateText
                );

            }
        });
    }
}