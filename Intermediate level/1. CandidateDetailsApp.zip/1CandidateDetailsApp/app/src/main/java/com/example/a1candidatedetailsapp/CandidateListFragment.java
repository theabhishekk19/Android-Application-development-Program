package com.example.a1candidatedetailsapp;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;

import java.util.ArrayList;

public class CandidateListFragment extends ListFragment {

    public interface OnCandidateSelectedListener {
        void onCandidateSelected(Candidate candidate);
    }

    private OnCandidateSelectedListener callback;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnCandidateSelectedListener) {
            callback = (OnCandidateSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnCandidateSelectedListener");
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ArrayList<String> names = new ArrayList<>();
        names.add("John Doe");
        names.add("Jane Smith");
        names.add("Mike Ross");

        setListAdapter(new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, names));
    }

    @Override
    public void onListItemClick(@NonNull ListView l, @NonNull View v, int position, long id) {
        String name = (String) getListAdapter().getItem(position);
        Candidate candidate = new Candidate(name, "Details for " + name + ":\nExperience: 5 Years\nRole: Android Developer");
        if (callback != null) {
            callback.onCandidateSelected(candidate);
        }
    }
}
