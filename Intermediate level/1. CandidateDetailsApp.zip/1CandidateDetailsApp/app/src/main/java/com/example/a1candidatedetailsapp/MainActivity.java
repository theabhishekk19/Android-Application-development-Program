package com.example.a1candidatedetailsapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements CandidateListFragment.OnCandidateSelectedListener {

    private boolean isLandscape;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if we are in landscape by checking for the existence of detail_container
        isLandscape = findViewById(R.id.detail_container) != null;

        if (savedInstanceState == null) {
            CandidateListFragment listFragment = new CandidateListFragment();
            int containerId = isLandscape ? R.id.list_container : R.id.fragment_container;

            getSupportFragmentManager().beginTransaction()
                    .add(containerId, listFragment)
                    .commit();
        }
    }

    @Override
    public void onCandidateSelected(Candidate candidate) {
        CandidateDetailFragment detailFragment = CandidateDetailFragment.newInstance(candidate);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        if (isLandscape) {
            // In landscape: replace the right pane
            transaction.replace(R.id.detail_container, detailFragment);
        } else {
            // In portrait: replace the whole screen and add to backstack
            transaction.replace(R.id.fragment_container, detailFragment);
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }
}
