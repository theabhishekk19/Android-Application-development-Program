package com.example.a1candidatedetailsapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CandidateDetailFragment extends Fragment {
    private static final String ARG_CANDIDATE = "candidate";

    public static CandidateDetailFragment newInstance(Candidate candidate) {
        CandidateDetailFragment fragment = new CandidateDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_CANDIDATE, candidate);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detail, container, false);
        TextView nameTv = view.findViewById(R.id.detail_name);
        TextView infoTv = view.findViewById(R.id.detail_info);

        if (getArguments() != null) {
            Candidate candidate = (Candidate) getArguments().getSerializable(ARG_CANDIDATE);
            if (candidate != null) {
                nameTv.setText(candidate.name);
                infoTv.setText(candidate.details);
            }
        }
        return view;
    }
}
