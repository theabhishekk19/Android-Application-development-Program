package com.example.a1candidatedetailsapp;

import java.io.Serializable;

public class Candidate implements Serializable {
    public String name;
    public String details;

    public Candidate(String name, String details) {
        this.name = name;
        this.details = details;
    }
}
