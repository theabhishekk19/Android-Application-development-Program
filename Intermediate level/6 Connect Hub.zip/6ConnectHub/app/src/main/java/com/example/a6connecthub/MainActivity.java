package com.example.a6connecthub;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Enable edge-to-edge display
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        // Initialize Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Handle window insets for edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Inflate the menu resource (menu_main.xml) into the toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Handle menu item clicks with Intents and Toasts
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_dial) {
            // Requirement 3a: Dial Number (ACTION_DIAL doesn't require CALL_PHONE permission)
            Toast.makeText(this, "Opening Dialer: 9876543210", Toast.LENGTH_SHORT).show();
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:9876543210"));
            startActivity(dialIntent);
            return true;
            
        } else if (id == R.id.action_web) {
            // Requirement 3b: Open Website
            Toast.makeText(this, "Opening Browser: google.com", Toast.LENGTH_SHORT).show();
            Intent webIntent = new Intent(Intent.ACTION_VIEW);
            webIntent.setData(Uri.parse("https://www.google.com"));
            startActivity(webIntent);
            return true;
            
        } else if (id == R.id.action_sms) {
            // Requirement 3c: Send SMS
            Toast.makeText(this, "Opening SMS app...", Toast.LENGTH_SHORT).show();
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
            smsIntent.setData(Uri.parse("smsto:9876543210"));
            smsIntent.putExtra("sms_body", "Hello from my app!");
            startActivity(smsIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
